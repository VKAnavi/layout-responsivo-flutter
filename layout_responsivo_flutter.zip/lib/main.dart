import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Layout Responsivo',
      home: ResponsiveLayout(),
    );
  }
}

class ResponsiveLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Layout Responsivo'),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          if (constraints.maxWidth < 600) {
            // Layout para telas pequenas (celulares)
            return Center(child: Text('Tela Pequena', style: TextStyle(fontSize: 24)));
          } else if (constraints.maxWidth < 1200) {
            // Layout para telas médias (tablets)
            return Center(child: Text('Tela Média', style: TextStyle(fontSize: 24)));
          } else {
            // Layout para telas grandes (desktops)
            return Center(child: Text('Tela Grande', style: TextStyle(fontSize: 24)));
          }
        },
      ),
    );
  }
}